Welcome! This website will allow you to track routes, view stations, and see trains!
Trains: Lists all of the Trains. User can add or update trains.
Stations: Lists all of the trains. User can add a station. They can also filter the station by their states.
Routes: Lists all of the Routes with the RoutesThruStations intersection table connected to each Routes. Shows each Routes and its corresponding Stations below in order.
